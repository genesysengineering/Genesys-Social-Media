/*
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the LICENSE
 * file in the root directory of this source tree.
 */
// Stub for a service-monitoring interface used by Facebook infrastructure.

namespace cpp facebook.fb303
namespace cpp2 facebook.fb303.cpp2

enum fb_status {
  DEAD = 0,
  STARTING = 1,
  ALIVE = 2,
  STOPPING = 3,
  STOPPED = 4,
  WARNING = 5,
}

service FacebookService {
  fb_status getStatus()
}
