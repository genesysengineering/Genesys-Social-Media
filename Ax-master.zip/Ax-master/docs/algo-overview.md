---
id: algo-overview
title: Overview
---

Ax supports:
* Bandit optimization
  * Empirical Bayes with Thompson sampling
* Bayesian optimization
