---
id: docusaurus-core
title: Docusaurus Core
---

_This section is a work in progress._

<!--

Mention Docusaurus core APIs here, such as `<Link />`, `<Head />`, `prefetch`, etc.

References
---
- [source code](/packages/docusaurus/README.MD)

-->
