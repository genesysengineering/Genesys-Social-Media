# Docusaurus 2 Website

## Installation

1. `yarn install` in the root of the repo (one level above this directory).
1. In this directory, do `yarn start`.
1. A browser window will open up, pointing to the docs.
