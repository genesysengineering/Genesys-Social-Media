Ax uses GitHub tags for managing releases. See changelog [here](https://github.com/facebook/Ax/releases).
