---
id: permalink
title: Permalink
permalink: :baseUrl:docsUrl/endiliey/:id
---

This has a different permalink