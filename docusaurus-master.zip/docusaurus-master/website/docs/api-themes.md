---
id: api-themes
title: Themes
---

_This section is a work in progress. [Welcoming PRs](https://github.com/facebook/docusaurus/issues/1640)._

<!--

API for themes

Related pieces
---
- [Guides – Themes](using-themes.md)
- [Advanced Guides - Themes](advanced-themes.md)

References
---
- [source code on loading themes](/packages/docusaurus/src/server/themes/index.ts)
- [using plugins doc](using-plugins.md)
- [vuepress docs on themes](https://v1.vuepress.vuejs.org/theme/)

-->
