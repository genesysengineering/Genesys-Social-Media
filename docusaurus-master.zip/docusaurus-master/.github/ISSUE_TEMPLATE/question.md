---
name: ❓ Questions/Help
about: If you have questions, please check Stack Overflow or Discord or Twitter
---

## ❓ Questions and Help

### Please note that this issue tracker is not a help form and this issue will be closed.

Please contact us instead. We have a few channels:

- [Stack Overflow](https://stackoverflow.com/questions/tagged/docusaurus)
- [Twitter](https://twitter.com/docusaurus)
- [Discord](https://discord.gg/docusaurus)
