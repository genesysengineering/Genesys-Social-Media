.. role:: hidden
    :class: hidden-section

ax.runners
===================================

.. automodule:: ax.runners
.. currentmodule:: ax.runners


Synthetic Runner
~~~~~~~~~~~~~~~~

.. automodule:: ax.runners.synthetic
    :members:
    :undoc-members:
    :show-inheritance:
