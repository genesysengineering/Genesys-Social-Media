### compiler
A binary to parse .thrift files and to generate corresponding client and server code in each target language

### doc
The official Facebook Thrift documentation

### lib
Runtime libraries for each target language

### perf
Thrift performance benchmarks

### example
Learn how to use Thrift
