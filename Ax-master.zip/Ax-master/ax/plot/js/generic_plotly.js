/*
 * Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
 */

Plotly.newPlot(
  {{id}},
  {{data}},
  {{layout}},
  {"showLink": false}
);
