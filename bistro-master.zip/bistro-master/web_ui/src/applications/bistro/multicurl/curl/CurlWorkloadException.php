<?php // strict
// Copyright 2004-present Facebook. All Rights Reserved.

final class CurlWorkloadException extends Exception {
}
