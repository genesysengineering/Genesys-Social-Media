/*
 * Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
 */

require(['plotly'], function(Plotly) {
  window.PLOTLYENV = window.PLOTLYENV || {};
  window.PLOTLYENV.BASE_URL = 'https://plot.ly';
  {{script}}
});
