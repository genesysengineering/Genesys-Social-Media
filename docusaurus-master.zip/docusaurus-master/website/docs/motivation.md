---
id: motivation
title: Motivation
description: Motivation of Docusaurus
---

#### References

- https://redux.js.org/introduction/motivation
