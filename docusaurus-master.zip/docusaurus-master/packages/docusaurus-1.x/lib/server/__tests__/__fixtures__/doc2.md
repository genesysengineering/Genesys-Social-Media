---
id: doc2
title: Document 2
---

### Existing Docs

- [doc1](doc1.md)
- [doc2](./doc2.md)

### Non-existing Docs

- [hahaha](hahaha.md)

## Repeating Docs

- [doc1](doc1.md)
- [doc2](./doc2.md)

## Do not replace this
```md
![image1](assets/image1.png)
```

```js
const doc1 = foo();
console.log("[image2](assets/image2.jpg)");
const testStr = `![image3](assets/image3.gif)`;
```