# Changelog

All notable changes to this project will be documented in this file.


## Unreleased

## v3.3.1
### Changed
- Remove list of API call from Business SDK,   [here](https://developers.facebook.com/docs/graph-api/changelog/4-30-2019-endpoint-deprecations)

## v3.3.0
### Changed
- Graph API call upgrade to [v3.3](https://developers.facebook.com/docs/graph-api/changelog/version3.3)
