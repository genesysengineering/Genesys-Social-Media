/*
 * Copyright (c) Facebook, Inc. and its affiliates. All Rights Reserved.
 */

var css = document.createElement('style');
css.type = 'text/css';
css.innerHTML = "{{css}}";
document.getElementsByTagName("head")[0].appendChild(css);
