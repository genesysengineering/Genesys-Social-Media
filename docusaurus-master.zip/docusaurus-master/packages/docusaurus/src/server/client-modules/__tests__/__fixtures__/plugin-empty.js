module.exports = function() {
  return {
    name: 'plugin-empty',
  };
};
